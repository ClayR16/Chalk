function foo() {
	foo();
}

foo();